﻿namespace EncryptAllFiles
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.rbtnEncrypt = new System.Windows.Forms.RadioButton();
            this.rbtnDecrypt = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.toolTipBrowse = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipEncrypt = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipDecrypt = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipPassword = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipStart = new System.Windows.Forms.ToolTip(this.components);
            this.txtEncrypt = new System.Windows.Forms.TextBox();
            this.txtPlain = new System.Windows.Forms.TextBox();
            this.txtDecrypt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.txtPlainPath = new System.Windows.Forms.TextBox();
            this.txtEncryptPath = new System.Windows.Forms.TextBox();
            this.txtDecryptPath = new System.Windows.Forms.TextBox();
            this.btnViewEncrypted = new System.Windows.Forms.Button();
            this.btnViewDecrypted = new System.Windows.Forms.Button();
            this.lblHeading1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnBrowseContent = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "File Path:";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(27, 107);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(565, 22);
            this.txtPath.TabIndex = 1;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(653, 99);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(100, 42);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // rbtnEncrypt
            // 
            this.rbtnEncrypt.AutoSize = true;
            this.rbtnEncrypt.Location = new System.Drawing.Point(191, 146);
            this.rbtnEncrypt.Name = "rbtnEncrypt";
            this.rbtnEncrypt.Size = new System.Drawing.Size(94, 21);
            this.rbtnEncrypt.TabIndex = 3;
            this.rbtnEncrypt.TabStop = true;
            this.rbtnEncrypt.Text = "ENCRYPT";
            this.rbtnEncrypt.UseVisualStyleBackColor = true;
            this.rbtnEncrypt.CheckedChanged += new System.EventHandler(this.rbtnEncrypt_CheckedChanged);
            // 
            // rbtnDecrypt
            // 
            this.rbtnDecrypt.AutoSize = true;
            this.rbtnDecrypt.Location = new System.Drawing.Point(309, 146);
            this.rbtnDecrypt.Name = "rbtnDecrypt";
            this.rbtnDecrypt.Size = new System.Drawing.Size(94, 21);
            this.rbtnDecrypt.TabIndex = 4;
            this.rbtnDecrypt.TabStop = true;
            this.rbtnDecrypt.Text = "DECRYPT";
            this.rbtnDecrypt.UseVisualStyleBackColor = true;
            this.rbtnDecrypt.CheckedChanged += new System.EventHandler(this.rbtnDecrypt_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 200);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password:";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(103, 195);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(489, 22);
            this.txtPassword.TabIndex = 6;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(27, 241);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(726, 95);
            this.btnStart.TabIndex = 7;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // txtEncrypt
            // 
            this.txtEncrypt.Location = new System.Drawing.Point(290, 566);
            this.txtEncrypt.Multiline = true;
            this.txtEncrypt.Name = "txtEncrypt";
            this.txtEncrypt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtEncrypt.Size = new System.Drawing.Size(194, 153);
            this.txtEncrypt.TabIndex = 8;
            // 
            // txtPlain
            // 
            this.txtPlain.Location = new System.Drawing.Point(24, 566);
            this.txtPlain.Multiline = true;
            this.txtPlain.Name = "txtPlain";
            this.txtPlain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPlain.Size = new System.Drawing.Size(194, 153);
            this.txtPlain.TabIndex = 9;
            // 
            // txtDecrypt
            // 
            this.txtDecrypt.Location = new System.Drawing.Point(556, 566);
            this.txtDecrypt.Multiline = true;
            this.txtDecrypt.Name = "txtDecrypt";
            this.txtDecrypt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDecrypt.Size = new System.Drawing.Size(194, 153);
            this.txtDecrypt.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 426);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Password:";
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(103, 423);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(647, 22);
            this.txtPass.TabIndex = 13;
            this.txtPass.Text = "The quick brown fox jumps over the lazy dog";
            // 
            // txtPlainPath
            // 
            this.txtPlainPath.Location = new System.Drawing.Point(24, 527);
            this.txtPlainPath.Name = "txtPlainPath";
            this.txtPlainPath.Size = new System.Drawing.Size(194, 22);
            this.txtPlainPath.TabIndex = 17;
            // 
            // txtEncryptPath
            // 
            this.txtEncryptPath.Location = new System.Drawing.Point(290, 527);
            this.txtEncryptPath.Name = "txtEncryptPath";
            this.txtEncryptPath.Size = new System.Drawing.Size(194, 22);
            this.txtEncryptPath.TabIndex = 18;
            // 
            // txtDecryptPath
            // 
            this.txtDecryptPath.Location = new System.Drawing.Point(556, 527);
            this.txtDecryptPath.Name = "txtDecryptPath";
            this.txtDecryptPath.Size = new System.Drawing.Size(194, 22);
            this.txtDecryptPath.TabIndex = 19;
            // 
            // btnViewEncrypted
            // 
            this.btnViewEncrypted.Location = new System.Drawing.Point(290, 470);
            this.btnViewEncrypted.Name = "btnViewEncrypted";
            this.btnViewEncrypted.Size = new System.Drawing.Size(194, 51);
            this.btnViewEncrypted.TabIndex = 20;
            this.btnViewEncrypted.Text = "View and Save Encrypted Content";
            this.btnViewEncrypted.UseVisualStyleBackColor = true;
            this.btnViewEncrypted.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // btnViewDecrypted
            // 
            this.btnViewDecrypted.Location = new System.Drawing.Point(556, 470);
            this.btnViewDecrypted.Name = "btnViewDecrypted";
            this.btnViewDecrypted.Size = new System.Drawing.Size(194, 51);
            this.btnViewDecrypted.TabIndex = 21;
            this.btnViewDecrypted.Text = "View and Save Decrypted Content";
            this.btnViewDecrypted.UseVisualStyleBackColor = true;
            this.btnViewDecrypted.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // lblHeading1
            // 
            this.lblHeading1.AutoSize = true;
            this.lblHeading1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading1.Location = new System.Drawing.Point(201, 21);
            this.lblHeading1.Name = "lblHeading1";
            this.lblHeading1.Size = new System.Drawing.Size(391, 25);
            this.lblHeading1.TabIndex = 22;
            this.lblHeading1.Text = "ENCRYPT DIRECTLY TO DIRECTORY";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(262, 375);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(245, 25);
            this.label7.TabIndex = 23;
            this.label7.Text = "VIEW FILE CONTENTS";
            // 
            // btnBrowseContent
            // 
            this.btnBrowseContent.Location = new System.Drawing.Point(24, 470);
            this.btnBrowseContent.Name = "btnBrowseContent";
            this.btnBrowseContent.Size = new System.Drawing.Size(194, 51);
            this.btnBrowseContent.TabIndex = 24;
            this.btnBrowseContent.Text = "Browse for file to encrypt";
            this.btnBrowseContent.UseVisualStyleBackColor = true;
            this.btnBrowseContent.Click += new System.EventHandler(this.btnBrowseContent_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 760);
            this.Controls.Add(this.btnBrowseContent);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblHeading1);
            this.Controls.Add(this.btnViewDecrypted);
            this.Controls.Add(this.btnViewEncrypted);
            this.Controls.Add(this.txtDecryptPath);
            this.Controls.Add(this.txtEncryptPath);
            this.Controls.Add(this.txtPlainPath);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDecrypt);
            this.Controls.Add(this.txtPlain);
            this.Controls.Add(this.txtEncrypt);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rbtnDecrypt);
            this.Controls.Add(this.rbtnEncrypt);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "File Encrypt & Decrypt";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.RadioButton rbtnEncrypt;
        private System.Windows.Forms.RadioButton rbtnDecrypt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ToolTip toolTipBrowse;
        private System.Windows.Forms.ToolTip toolTipEncrypt;
        private System.Windows.Forms.ToolTip toolTipDecrypt;
        private System.Windows.Forms.ToolTip toolTipPassword;
        private System.Windows.Forms.ToolTip toolTipStart;
        private System.Windows.Forms.TextBox txtEncrypt;
        private System.Windows.Forms.TextBox txtPlain;
        private System.Windows.Forms.TextBox txtDecrypt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.TextBox txtPlainPath;
        private System.Windows.Forms.TextBox txtEncryptPath;
        private System.Windows.Forms.TextBox txtDecryptPath;
        private System.Windows.Forms.Button btnViewEncrypted;
        private System.Windows.Forms.Button btnViewDecrypted;
        private System.Windows.Forms.Label lblHeading1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnBrowseContent;
    }
}

